<?php
session_start();
$db = new mysqli('localhost', 'root', '', 'crude');
