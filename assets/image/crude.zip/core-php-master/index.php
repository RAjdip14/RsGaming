<?php
include('includes/header.php');
?>
<h1>This is home page</h1>
<?php
include('includes/footer.php');
?>