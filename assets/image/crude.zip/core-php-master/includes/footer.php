
    <div class="footer">
        <p>All rights are reserved <?php echo date('Y');?>&copy;&reg;</p>
    </div>
</body>
</html>